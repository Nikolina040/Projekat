<?php 

include("dbconnection.php");

$tretman_id = $_REQUEST['tretman_id'];
$zivotinja_id = $_REQUEST['zivotinja_id'];
$tip = $_REQUEST['tip'];
$datum = $_REQUEST['datum'];
$napomena = $_REQUEST['napomena'];


if(!empty($tretman_id) && !empty($zivotinja_id) && !empty($tip) && !empty($datum) && !empty($napomena)){
    $statement = $mysqli->prepare("INSERT INTO veterinarski_tretmani(tretman_id, zivotinja_id, tip, datum, napomena) VALUES (?, ?, ?, ?, ?)");

    $statement->bind_param("sssss", $tretman_id, $zivotinja_id, $tip, $datum, $napomena);

    if($statement->execute()){
        header("Location: ../napraviTretman.php?success=1");
    } else {
        die("Error : (" . $mysqli->errno . ") " . $mysqli->error); 
    }
}


?>