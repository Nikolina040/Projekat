<?php 

include("dbconnection.php");

$volonter_id = $_REQUEST['volonter_id'];
$ime = $_REQUEST['ime'];
$prezime = $_REQUEST['prezime'];
$godine = $_REQUEST['godine'];
$kontakt_telefon = $_REQUEST['kontakt_telefon'];
$email = $_REQUEST['email'];
$adresa = $_REQUEST['adresa'];

if(!empty($volonter_id) && !empty($ime) && !empty($prezime) && !empty($godine) && !empty($kontakt_telefon) && !empty($email) && !empty($adresa)){
    $statement = $mysqli->prepare("INSERT INTO volonteri(volonter_id, ime, prezime, godine, kontakt_telefon, email, adresa) VALUES (?, ?, ?, ?, ?, ?, ?)");

    $statement->bind_param("sssssss", $volonter_id, $ime, $prezime, $godine, $kontakt_telefon, $email, $adresa);

    if($statement->execute()){
        header("Location: ../napraviVolontera.php?success=1");
    } else {
        die("Error : (" . $mysqli->errno . ") " . $mysqli->error); 
    }
}


?>