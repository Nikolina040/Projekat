-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2024 at 01:37 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zastitazivotinja`
--

-- --------------------------------------------------------

--
-- Table structure for table `korisnici`
--

CREATE TABLE `korisnici` (
  `ime` text NOT NULL,
  `prezime` text NOT NULL,
  `telefon` text NOT NULL,
  `email` text NOT NULL,
  `sifra` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `korisnici`
--

INSERT INTO `korisnici` (`ime`, `prezime`, `telefon`, `email`, `sifra`) VALUES
('Nikolina', 'Djavolovic', '0630555333', 'Nikolina@gmail.com', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Table structure for table `usvojenja`
--

CREATE TABLE `usvojenja` (
  `usvojenje_id` int(11) NOT NULL,
  `zivotinja_id` int(11) DEFAULT NULL,
  `datum_usvojenja` date DEFAULT NULL,
  `adopcija_fee` double DEFAULT NULL,
  `adopter_ime` text DEFAULT NULL,
  `adopter_adresa` text DEFAULT NULL,
  `kontakt_telefon` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usvojenja`
--

INSERT INTO `usvojenja` (`usvojenje_id`, `zivotinja_id`, `datum_usvojenja`, `adopcija_fee`, `adopter_ime`, `adopter_adresa`, `kontakt_telefon`) VALUES
(1, 1, '2024-05-01', 1000, 'Nikola Nikolic', 'Kralja Petra Prvog', '0638889990'),
(2, 2, '2024-05-19', 800, 'Jelena Jecic', 'Svetozara Markovica', '0616871429');

-- --------------------------------------------------------

--
-- Table structure for table `veterinarski_tretmani`
--

CREATE TABLE `veterinarski_tretmani` (
  `tretman_id` int(11) NOT NULL,
  `zivotinja_id` int(11) DEFAULT NULL,
  `tip` text DEFAULT NULL,
  `datum` date DEFAULT NULL,
  `napomena` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `veterinarski_tretmani`
--

INSERT INTO `veterinarski_tretmani` (`tretman_id`, `zivotinja_id`, `tip`, `datum`, `napomena`) VALUES
(1, 1, 'Vakcinacija', '2024-05-01', 'Vakcinacija super podneta, nije bilo agresije'),
(2, 2, 'Sterilizacija', '2024-05-10', 'Sterilizacija uspesna, zivotinja je u dobrom stanju, nema posledica'),
(3, 3, 'Specijalna dijeta', '2024-05-16', 'Specijalna dijeta za lecenje alergije na odredjenu hranu');

-- --------------------------------------------------------

--
-- Table structure for table `volonteri`
--

CREATE TABLE `volonteri` (
  `volonter_id` int(11) NOT NULL,
  `ime` text DEFAULT NULL,
  `prezime` text DEFAULT NULL,
  `godine` int(11) DEFAULT NULL,
  `kontakt_telefon` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `adresa` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `volonteri`
--

INSERT INTO `volonteri` (`volonter_id`, `ime`, `prezime`, `godine`, `kontakt_telefon`, `email`, `adresa`) VALUES
(1, 'Milan', 'Milikic', 24, '0667685431', 'milanMilika@gmail.com', 'Save Kovacevica 13'),
(2, 'Sara', 'Popovic', 22, '0622255767', 'Popovic00@gmail.com', 'Vuka Karadzica'),
(3, 'Neko', 'Neko', 30, '0601113333', 'Neko@gmail.com', 'Neko Neko Neko');

-- --------------------------------------------------------

--
-- Table structure for table `zivotinje`
--

CREATE TABLE `zivotinje` (
  `zivotinja_id` int(11) NOT NULL,
  `vrsta` text DEFAULT NULL,
  `rasa` text DEFAULT NULL,
  `pol` text DEFAULT NULL,
  `godine` int(11) DEFAULT NULL,
  `ime` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `zivotinje`
--

INSERT INTO `zivotinje` (`zivotinja_id`, `vrsta`, `rasa`, `pol`, `godine`, `ime`) VALUES
(1, 'Pas', 'Bernski Planinski Pas', 'Muski', 2, 'Bak'),
(2, 'Macka', 'Birmankska', 'Zenski', 1, 'Luna'),
(3, 'Pas', 'Rotvajler', 'Muski', 1, 'Onix');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `usvojenja`
--
ALTER TABLE `usvojenja`
  ADD PRIMARY KEY (`usvojenje_id`),
  ADD KEY `zivotinja_id` (`zivotinja_id`);

--
-- Indexes for table `veterinarski_tretmani`
--
ALTER TABLE `veterinarski_tretmani`
  ADD PRIMARY KEY (`tretman_id`),
  ADD KEY `zivotinja_id` (`zivotinja_id`);

--
-- Indexes for table `volonteri`
--
ALTER TABLE `volonteri`
  ADD PRIMARY KEY (`volonter_id`);

--
-- Indexes for table `zivotinje`
--
ALTER TABLE `zivotinje`
  ADD PRIMARY KEY (`zivotinja_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `usvojenja`
--
ALTER TABLE `usvojenja`
  ADD CONSTRAINT `usvojenja_ibfk_1` FOREIGN KEY (`zivotinja_id`) REFERENCES `zivotinje` (`zivotinja_id`);

--
-- Constraints for table `veterinarski_tretmani`
--
ALTER TABLE `veterinarski_tretmani`
  ADD CONSTRAINT `veterinarski_tretmani_ibfk_1` FOREIGN KEY (`zivotinja_id`) REFERENCES `zivotinje` (`zivotinja_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
